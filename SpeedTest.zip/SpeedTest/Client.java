import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Client {
    private static final int UDP_PORT = 9876;

    private static byte[] prepareData(int numElements) {
        byte[] data = new byte[numElements];
        for (int i = 0; i < numElements; i++) {
            data[i] = (byte) (i % 256);
        }
        return data;
    }

    private static void sendContinuousTCPData(Socket tcpSocket, int bufferSize, boolean useNagle) {
        try {
            tcpSocket.getOutputStream().write(("SIZE:" + bufferSize).getBytes("UTF-8"));

            while (true) {
                tcpSocket.getOutputStream().write(prepareData(bufferSize));
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                tcpSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static void sendContinuousUDPData(DatagramSocket udpSocket, int bufferSize) {
        try {
            String message = "SIZE:" + bufferSize;
            DatagramPacket sizePacket = new DatagramPacket(message.getBytes("UTF-8"), message.length(),
                    InetAddress.getByName("localhost"), UDP_PORT);
            udpSocket.send(sizePacket);

            while (true) {
                DatagramPacket dataPacket = new DatagramPacket(prepareData(bufferSize), bufferSize,
                        InetAddress.getByName("localhost"), UDP_PORT);
                udpSocket.send(dataPacket);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                String fineMessage = "FINE";
                DatagramPacket finePacket = new DatagramPacket(fineMessage.getBytes("UTF-8"), fineMessage.length(),
                        InetAddress.getByName("localhost"), UDP_PORT);
                udpSocket.send(finePacket);

                udpSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static List<String[]> discoverServers(DatagramSocket multicastDiscoverySocket) {
        List<String[]> servers = new ArrayList<>();
        try {
            String discoveryMessage = "DISCOVERY";
            DatagramPacket discoveryPacket = new DatagramPacket(discoveryMessage.getBytes("UTF-8"),
                    discoveryMessage.length(), InetAddress.getByName("224.0.0.1"), UDP_PORT);
            multicastDiscoverySocket.send(discoveryPacket);

            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            multicastDiscoverySocket.receive(receivePacket);

            String offerMessage = new String(receivePacket.getData(), 0, receivePacket.getLength(), "UTF-8");
            String[] serverInfo = offerMessage.split(":");
            servers.add(serverInfo);

        } catch (IOException e) {
            e.printStackTrace();
        }
        return servers;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the communication port number: ");
        int PORT = scanner.nextInt();

        int TCP_PORT = PORT;
        Socket tcpClientSocket = new Socket();

        int MULTICAST_PORT = PORT;
        DatagramSocket multicastDiscoverySocket = null;
        try {
            multicastDiscoverySocket = new DatagramSocket(MULTICAST_PORT);
        } catch (SocketException e) {
            e.printStackTrace();
        }

        List<String[]> servers = discoverServers(multicastDiscoverySocket);

        System.out.print("Do you want to manually input server IP and port? (y/n): ");
        String manualInput = scanner.next().toLowerCase();
        String serverIp;
        int serverPort;

        if (manualInput.equals("y")) {
            System.out.print("Enter server IP address: ");
            serverIp = scanner.next();
            System.out.print("Enter server port number: ");
            serverPort = scanner.nextInt();
        } else {
            String[] serverInfo = servers.get(0);
            serverIp = serverInfo[0];
            serverPort = Integer.parseInt(serverInfo[1]);
        }

        System.out.print("Enter the number of elements for the byte array: ");
        int numElements = scanner.nextInt();
        byte[] data = prepareData(numElements);

        int bufferSize = data.length;
        System.out.print("Do you want to include Nagle algorithm? (y/n): ");
        boolean useNagle = scanner.next().toLowerCase().equals("y");

        try {
            tcpClientSocket.connect(new InetSocketAddress(serverIp, TCP_PORT));
        } catch (IOException e) {
            e.printStackTrace();
        }

        DatagramSocket udpClientSocket = null;
        try {
            udpClientSocket = new DatagramSocket();
        } catch (SocketException e) {
            e.printStackTrace();
        }

        Thread continuousTcpThread = new Thread(() -> sendContinuousTCPData(tcpClientSocket, bufferSize,useNagle));
        DatagramSocket finalUdpClientSocket = udpClientSocket;
        Thread continuousUdpThread = new Thread(() -> sendContinuousUDPData(finalUdpClientSocket, bufferSize));

        continuousTcpThread.start();
        continuousUdpThread.start();

        System.out.print("Do you want to stop data transmissions? (y/n): ");
        String stopTransmissionsInput = scanner.next().toLowerCase();
        if (stopTransmissionsInput.equals("y")) {
            try {
                tcpClientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                continuousUdpThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        try {
            tcpClientSocket.close();
            udpClientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
