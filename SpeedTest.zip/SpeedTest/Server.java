import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class Server {
    private static final int BUFFER_SIZE = 1024;
    private static final int UDP_PORT = 9876;
    private static volatile boolean stopThreads = false;

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Uso: java Server <puerto>");
            System.exit(1);
        }

        int portNumber = Integer.parseInt(args[0]);

        Thread tcpThread = new Thread(() -> {
            boolean firstClient = false;
            try (ServerSocket serverSocket = new ServerSocket(portNumber)) {
                while (!stopThreads) {
                    Socket clientSocket = serverSocket.accept();

                    if (firstClient= true){
                        informOtherClients(clientSocket);
                        clientSocket.close();



                    }
                    Thread clientHandlerThread = new Thread(() -> handleClientMessages(clientSocket));
                    clientHandlerThread.start();

                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        tcpThread.start();

        Thread udpThread = new Thread(() -> {
            try (DatagramSocket udpSocket = new DatagramSocket(portNumber)) {
                while (!stopThreads) {
                    byte[] receiveData = new byte[BUFFER_SIZE];
                    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                    udpSocket.receive(receivePacket);
                    processUdpMessage(receivePacket);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        udpThread.start();

        Thread multicastThread = new Thread(() -> {
            try (MulticastSocket multicastSocket = new MulticastSocket(UDP_PORT)) {
                InetAddress group = InetAddress.getByName("224.0.0.1");
                multicastSocket.joinGroup(group);
                while (!stopThreads) {
                    byte[] receiveData = new byte[BUFFER_SIZE];
                    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                    multicastSocket.receive(receivePacket);
                    discoverServers(multicastSocket);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        multicastThread.start();
    }

    private static void informOtherClients(Socket currentClientSocket) throws IOException {

        try (PrintWriter out = new PrintWriter(currentClientSocket.getOutputStream(), true)) {
            out.println("BUSY");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static void handleClientMessages(Socket clientSocket) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {
            String inputLine;
            long startTime = System.currentTimeMillis();
            long totalBytesReceived = 0;
            while ((inputLine = in.readLine()) != null) {
                if ("FINE".equals(inputLine)) {
                    break;
                }
                if (inputLine.startsWith("SIZE:")) {
                    int bufferSize = Integer.parseInt(inputLine.substring(5));
                } else {
                    totalBytesReceived += inputLine.getBytes().length;
                    long elapsedTime = (System.currentTimeMillis() - startTime) / 1000;
                    double speed = (double) totalBytesReceived / elapsedTime / 1024;
                    System.out.printf("Thread (TCP): recibidos %.2f KB en %.2f seg con velocidad %.2f KB/s\n",
                            totalBytesReceived / 1024.0, elapsedTime, speed);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    private static void processUdpMessage(DatagramPacket receivePacket) {
        discoverServers((MulticastSocket) null);
    }

    private static void discoverServers(MulticastSocket multicastSocket) {
        try {
            byte[] receiveData = new byte[BUFFER_SIZE];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            multicastSocket.receive(receivePacket);
            String discoveryMessage = new String(receivePacket.getData(), 0, receivePacket.getLength(), "UTF-8");
            if ("DISCOVERY".equals(discoveryMessage)) {
                String offerMessage = "OFFER:" + UDP_PORT;
                byte[] offerData = offerMessage.getBytes("UTF-8");
                DatagramPacket offerPacket = new DatagramPacket(offerData, offerData.length,
                        InetAddress.getByName("224.0.0.1"), UDP_PORT);
                multicastSocket.send(offerPacket);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}